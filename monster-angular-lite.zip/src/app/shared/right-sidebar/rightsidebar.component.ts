import { Component, OnInit  } from '@angular/core';

@Component({
  selector: 'ap-rightsidebar',
  templateUrl: './rightsidebar.component.html'
})
export class RightSidebarComponent {
	constructor() {}
	ngOnInit() {
		
	}
}
